from itertools import product
import math
from pyecharts.charts import Sunburst
from pyecharts import options as opts
import json
import re
from imgcat import imgcat
import requests_html

session = requests_html.HTMLSession()
API_jsLogin = "https://login.wx.qq.com/jslogin?appid=wx782c26e4c19acffb&redirect_uri=https%3A%2F%2Fwx.qq.com%2Fcgi-bin%2Fmmwebwx-bin%2Fwebwxnewloginpage&fun=new&lang=zh_CN"
QR_code = "https://login.weixin.qq.com/qrcode/{}"


def get_qrcode_uid():
    resp = session.get(API_jsLogin)
    uid = re.split(r'"|";', resp.text)[1]
    print(f"uid is {uid}")
    return uid


def get_qrcode_img(uid):
    resp = session.get(QR_code.format(uid))
    return imgcat(resp.content)


uid = get_qrcode_uid()
get_qrcode_img(uid)

##############################################################################

import execjs
import time
import base64

API_login = "https://wx.qq.com/cgi-bin/mmwebwx-bin/login"
API_check_login = "https://login.wx.qq.com/cgi-bin/mmwebwx-bin/login"


def get_timestamp(reverse=False):
    if reverse:
        return execjs.eval("~new Date")
    return int(time.time() * 1e3)


def login_wait(confirm=True):
    return session.get(
        API_check_login if confirm else API_login,
        params={
            "loginicon": "true",
            "uuid": uid,
            "tip": 0 if confirm else 1,
            "r": get_timestamp(True),
            "_": get_timestamp(),
        },
        timeout=25,
    )


nums = 10
while nums > 0:
    try:
        print("等待客户端扫描，剩余次数", nums)
        res = login_wait()
        if "userAvatar" in res.text:
            print("即将打印头像")
            imgcat(base64.b64decode(re.findall("base64,(.*?)';", res.text)[0]))
            break
    except Exception as e:
        pass
    nums -= 1

print("等待客户端确认")
redirect_uri = re.findall('redirect_uri="(.*?)"', login_wait(True).text)[0]
print("即将跳转", redirect_uri)

##############################################################################

from pprint import pprint


def get_auth_data(resp):
    return {
        key: resp.html.find(key)[0].text
        for key in ["skey", "wxsid", "wxuin", "pass_ticket", "isgrayscale"]
    }


def get_ticket():
    resp = session.get(
        redirect_uri, params={"fun": "new", "lang": "zh_CN", "_": get_timestamp()}
    )
    print("Get Ticket:")
    pprint(requests_html.requests.utils.dict_from_cookiejar(resp.cookies))
    auth_data = get_auth_data(resp)
    session.cookies.update(
        requests_html.requests.utils.cookiejar_from_dict(
            {"last_wxuin": auth_data["wxuin"]}
        )
    )
    if list(filter(lambda item: item[1], auth_data.items())):
        return auth_data


auth_data = get_ticket()
print("Get Auth_data:")
pprint(auth_data)

##############################################################################

import random

API_webwxinit = "https://wx.qq.com/cgi-bin/mmwebwx-bin/webwxinit"
my_id = ""


def create_device_id():
    return f"e{str(random.random())[2:17]}"


def get_base_request():
    return {
        "BaseRequest": {
            "Uin": auth_data["wxuin"],
            "Sid": auth_data["wxsid"],
            "Skey": auth_data["skey"],
            "DeviceID": create_device_id(),
        }
    }


def login_success_init():
    resp = session.post(
        API_webwxinit, params={"r": get_timestamp(True)}, json=get_base_request()
    )
    resp.encoding = "utf8"
    data = resp.json()
    my_id = data["User"]["UserName"]
    print(f"{'Welcome'.center(20,'*')}: [{data['User']['NickName']}]")
    return data


person_data = login_success_init()


#####################

API_webwxgetcontact = "https://wx.qq.com/cgi-bin/mmwebwx-bin/webwxgetcontact"

contacts = {}


def get_contact():
    resp = session.get(
        API_webwxgetcontact,
        params={
            "lang": "zh_CN",
            "r": get_timestamp(),
            "seq": 0,
            "skey": auth_data["skey"],
        },
    )
    resp.encoding = "utf8"
    data = resp.json()
    print(f"Get friends: [{data['MemberCount']}]")
    return data


contacts = get_contact()


# ########################

import progressbar
import string
import pathlib
from io import BytesIO
from openpyxl import Workbook
from openpyxl.drawing.image import Image as openpyxlImage
from PIL import Image
from urllib.parse import urljoin

MAIN_URI = "https://wx.qq.com/"
MEDIA_PATH = pathlib.Path("images")


def get_pic(data):
    try:
        img = session.get(urljoin(MAIN_URI, data["HeadImgUrl"])).content
        with (MEDIA_PATH / f"{data['PYInitial']}_{data['VerifyFlag']}.png").open(
            "wb"
        ) as file:
            file.write(img)
        return img
    except Exception as e:
        print(e)


def export_all_contact():
    wb = Workbook()
    sheet = wb.active
    keys = contacts["MemberList"][0].keys()

    for x, key in enumerate(keys):  # 将列名写入第一行
        sheet.cell(row=1, column=x + 1, value=key)

    # 逐行写入数据
    for y, item in progressbar.progressbar(enumerate(contacts["MemberList"])):
        y = y + 2
        for x, key in enumerate(keys):  # 每行逐列写入数据
            x = x + 1
            value = item[key]  # 待填充值

            if key != "HeadImgUrl":  # 判断是否不为图片路径字段
                if key == "MemberList":
                    value = "".join(value)
                sheet.cell(row=y, column=x, value=value)  # 常规插入
            else:
                # 如果是图片路径那么就取到图片二进制流
                pic = get_pic(item)
                if pic:  # 确认确实有内容
                    x = x - 1
                    index_code = string.ascii_uppercase[x]  # 获取到对应列的字母
                    size = (50, 50)  # 指定图片的大小
                    sheet.column_dimensions[index_code].width, sheet.row_dimensions[
                        y
                    ].height = size  # 指定将单元格长宽
                    img = openpyxlImage(BytesIO(pic))  # 转换为行内可用图像
                    img.width, img.height = size  # 指定图像大小
                    sheet.add_image(img, f"{index_code}{y}")  # 插入该图
                else:
                    sheet.cell(row=y, column=x, value="")  # 没有图就空着
    wb.save("contacts.xlsx")


if not MEDIA_PATH.exists():
    MEDIA_PATH.mkdir()
export_all_contact()

# #####################################

from pyecharts import options as opts
from pyecharts.charts import Sunburst


def random_color():
    return "#" + "".join([random.choice("0123456789abcdef") for j in range(6)])


def format_sunburst_city(data):  # 整理好友城市数据，将其变为一个可以直接使用的字典
    datas = {}
    for item in data["MemberList"]:
        province = item["Province"]
        city = item["City"]
        if len(province) > 5:
            continue
        if province not in datas:
            datas[province] = {}
        if city not in datas[province]:
            datas[province][city] = 1
        else:
            datas[province][city] += 1

    result = []
    for province, pitem in datas.items():
        result.append(
            {
                "name": province,
                "itemStyle": {"color": random_color()},
                "children": [
                    {
                        "name": city,
                        "value": citem,
                        "itemStyle": {"color": random_color()},
                    }
                    for city, citem in pitem.items()
                ],
            }
        )
    return result


contacts_formated = format_sunburst_city(contacts)


def sunburst_city(data) -> Sunburst:  # 直接带入固定格式数据生成图像
    return (
        Sunburst(init_opts=opts.InitOpts(width="1000px", height="600px"))  # 设定画布长宽
        .add(
            "",
            data_pair=data,  # 载入数据
            highlight_policy="ancestor",
            radius=[0, "95%"],
            sort_="null",
            levels=[
                {},  # 第一圈样式，如果有国家的话就不会空着
                {
                    "r0": "15%",
                    "r": "45%",
                    "itemStyle": {"borderWidth": 2},
                    "label": {"rotate": "tangential"},
                },  # 第二圈样式，对标省
                {
                    "r0": "35%",
                    "r": "70%",
                    "label": {"position": "outside", "padding": 3, "silent": False},
                    "itemStyle": {"borderWidth": 1},
                },  # 最外圈样式，对标市
            ],
        )
        # 设定标题
        .set_global_opts(title_opts=opts.TitleOpts(title="Sunburst-城市分布"))
        .set_series_opts(label_opts=opts.LabelOpts(formatter="{b}"))  # 设定名称
    )


print("result:", sunburst_city(contacts_formated).render())


# #####################

from itertools import product

length, weight = (1024, 768)


def check_if_can_open(path):
    try:
        return Image.open(path)
    except Exception as e:
        pass


def make_friends_icon_wall():
    images = list(filter(check_if_can_open, MEDIA_PATH.glob("*_0.png")))  # 搜索并过滤为个人的微信号
    images_length = len(images)  # 计算长度
    per_size = int(math.sqrt(length * weight / images_length))  # 计算平均尺寸，正方形
    image = Image.new("RGBA", (length, weight))  # 设定画布
    for indexs, (x, y) in enumerate(
        product(range(int(length / per_size)), range(int(weight / per_size)))
    ):  # 迭代全部图像及XY坐标
        if indexs >= images_length:
            break
        img = Image.open(images[indexs])  # 打开图像
        img = img.resize((per_size, per_size), Image.ANTIALIAS)  # 重新指定头像尺寸
        image.paste(img, (x * per_size, y * per_size))  # 指定对应行列起始点，并粘贴头像
    image.save("friends_icon_wall.png")  # 保存结果
    print("friends_icon_wall saved!")


make_friends_icon_wall()


###################################################


import jieba
from wordcloud import WordCloud
from pyquery import PyQuery as jq


def filter_html(text):
    try:
        return jq(text).text()
    except Exception as e:
        return text


def make_friends_signature_word_cloud():
    words = "\n".join([filter_html(item["Signature"])
                       for item in contacts["MemberList"]])  # 整合签名
    jiebares = " ".join(jieba.cut(words))  # 中文分词
    wc = WordCloud(
        background_color="white",
        font_path="HYQiHei-25J.ttf",
        max_words=300,
        max_font_size=40,
        random_state=45,
    )  # 词云配置信息
    wc.generate(jiebares)  # 生成词云
    wc.to_file("friends_signature_word_cloud.png")  # 保存
    print("friends_signature_word_cloud saved!")


make_friends_signature_word_cloud()


import json
with pathlib.Path('contacts.json').open('w') as file:
    file.write(json.dumps(contacts,indent=4,ensure_ascii=False))
    print("contacts.json saved!")
